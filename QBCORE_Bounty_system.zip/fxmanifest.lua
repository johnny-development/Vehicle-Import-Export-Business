fx_version 'cerulean'
game 'gta5'

author 'Dingos Development Developer: Johnny'
description 'Custom Bounty System for FiveM'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
